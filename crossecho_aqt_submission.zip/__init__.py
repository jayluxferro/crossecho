"""Paper draft for CrossEcho."""
